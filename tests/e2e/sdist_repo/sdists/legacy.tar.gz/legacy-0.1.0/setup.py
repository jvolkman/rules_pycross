from setuptools import setup
setup(name='legacy', version='0.1.0')
