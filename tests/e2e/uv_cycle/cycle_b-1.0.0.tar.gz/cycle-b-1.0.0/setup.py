from setuptools import setup
setup(name='cycle-b', version='1.0.0', packages=['cycle_b'])
