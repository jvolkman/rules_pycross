from setuptools import setup
setup(name='cycle-a', version='1.0.0', packages=['cycle_a'])
