"""Synthetic wrapper package for extras isolation e2e test."""
VALUE = "wrapper"
