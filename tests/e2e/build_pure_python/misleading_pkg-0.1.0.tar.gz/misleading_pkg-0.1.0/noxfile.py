# Stray root script that fools repo-time layout guessing.
