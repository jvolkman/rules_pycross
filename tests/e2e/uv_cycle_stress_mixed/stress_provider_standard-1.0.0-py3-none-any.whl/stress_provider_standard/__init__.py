"""Synthetic package stress-provider-standard for cycle stress testing."""
