"""Synthetic package stress-attrs for cycle stress testing."""
