"""Synthetic package stress-task-sdk for cycle stress testing."""
