"""Synthetic package stress-provider-compat for cycle stress testing."""
