"""Synthetic package stress-airflow for cycle stress testing."""
