"""Synthetic package stress-provider-smtp for cycle stress testing."""
