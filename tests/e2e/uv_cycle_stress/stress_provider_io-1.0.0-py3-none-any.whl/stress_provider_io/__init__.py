"""Synthetic package stress-provider-io for cycle stress testing."""
