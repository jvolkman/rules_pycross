"""Synthetic package stress-jinja2 for cycle stress testing."""
