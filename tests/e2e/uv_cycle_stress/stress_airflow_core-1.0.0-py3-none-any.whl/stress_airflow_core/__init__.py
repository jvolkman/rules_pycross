"""Synthetic package stress-airflow-core for cycle stress testing."""
