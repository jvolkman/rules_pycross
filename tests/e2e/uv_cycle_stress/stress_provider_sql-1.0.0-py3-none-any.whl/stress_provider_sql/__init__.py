"""Synthetic package stress-provider-sql for cycle stress testing."""
